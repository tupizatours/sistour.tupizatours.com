<script>
    window.location.href = "{{ url('login') }}";
</script>